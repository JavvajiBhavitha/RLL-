package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
public class SortByPage {
	 WebDriver driver;

	By sortByIcon = By.xpath("//div[contains(text(), 'Sort By')]");
	By sortByDropdown = By.xpath("//select[@id='ddlSort']");
	By price=By.xpath("//*[@id=\"ddlSort\"]/option[3]");
	By discount=By.xpath("//option[contains(text(),\"Discount\")]");

	// Constructor
	public SortByPage(WebDriver driver) {
		this.driver = driver;
	}

	public void launch() {
		driver.get("https://www.bookswagon.com/promo-best-seller/award-winning/2109CDC4B4DC");
	}

	public void navigateToSortBy() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(sortByIcon));
		driver.findElement(sortByIcon).click();
		System.out.println("navigate to sort by");
	}

	public void sortByPrice() {
		WebElement e=driver.findElement(price);
		e.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
		System.out.println("price");
	}
	public void sortByDiscount() {
		WebElement e=driver.findElement(discount);
		e.click();
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(3));
		System.out.println("discount");
	}
	public void verifyDefaultSorting() {
		driver.findElement(sortByDropdown).click();
		System.out.println("default");
	}


}
