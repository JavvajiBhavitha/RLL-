package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 

public class AddingItemtoShoppingCart { 
	WebDriver driver; 
	By Bookname = By.xpath("//*[@id=\"listSearchResult\"]/div[3]/div[3]/div[1]/a"); 
	By Cartbutton = By.id("btnAddtocart"); 

	public AddingItemtoShoppingCart(WebDriver driver) { 
		this.driver = driver;	 
	} 
	public void ClickBookName() throws InterruptedException { 
		driver.findElement(Bookname).click(); 
		Thread.sleep(2000); 
	} 
	public void addItemToCart() throws InterruptedException { 
		driver.findElement(Cartbutton).click(); 
		Thread.sleep(2000); 
	} 
} 

