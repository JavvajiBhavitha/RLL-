package com.pages.RLL_240Testing_Bookswagon;
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 

public class Page_File_Search_RefineSearch { 

    private WebDriver driver; 

 

    // Locators 

     By searchBox = By.id("inputbar"); 

     By searchButton = By.id("btnTopSearch"); 

     By searchResults = By.xpath("/a[@href='https://www.bookswagon.com/book/rahasya-secret-byrne-rhonda/9788183220941']"); // Replace with actual locator 

     By noResultsMessage = By.xpath("//div[@class='not-match' and contains(text(), 'did not match any books')]\r\n"); // Replace with actual locator 

     

    // Constructor 

    public Page_File_Search_RefineSearch(WebDriver driver) { 

        this.driver = driver; 

    } 
    public void Navigate_To_Result_Page() {
    	
    	driver.get("https://www.bookswagon.com/search-books/the-secret");
    }

 

    // Method to enter search item 

    public void enterSearchItem(String item) throws InterruptedException { 

        WebElement searchBoxElement = driver.findElement(searchBox); 

        searchBoxElement.sendKeys(item); 
        Thread.sleep(3000);

       

    } 

 

    // Method to click the search button 

    public void clickSearchButton() throws InterruptedException { 

        driver.findElement(searchButton).click(); 

        Thread.sleep(1000); 

    } 

     

 // Method to get the search results 

    public void getSearchResults() throws InterruptedException { 

       WebElement RM1= driver.findElement(searchResults);
    		   RM1.getText(); 
    		   RM1.clear();

        Thread.sleep(2000); 

    } 

    // Method to get the no results message 

    public void getNoResultsMessage() throws InterruptedException { 

       WebElement RM= driver.findElement(noResultsMessage);
    		   RM.getText(); 
    		   RM.clear();

        Thread.sleep(1000); 

    }   

} 