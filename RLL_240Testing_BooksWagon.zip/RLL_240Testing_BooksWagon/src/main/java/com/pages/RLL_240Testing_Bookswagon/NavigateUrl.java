package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.WebDriver; 


public class NavigateUrl { 
	WebDriver driver; 
	public NavigateUrl(WebDriver driver) { 
		this.driver = driver; 
	} 
	public void Navigate() { 
		driver.navigate().to("https://www.bookswagon.com/search-books/the-secret"); 
	} 

}
