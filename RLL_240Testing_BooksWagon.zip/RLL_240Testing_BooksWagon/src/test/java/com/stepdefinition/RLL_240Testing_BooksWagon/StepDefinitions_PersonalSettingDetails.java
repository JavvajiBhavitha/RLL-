package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.apache.log4j.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import com.pages.RLL_240Testing_Bookswagon.PersonalSettingDetails;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions_PersonalSettingDetails {


	    WebDriver driver;

	     PersonalSettingDetails psd;
	     Logger log;

	    @Before
	    public void init() {
	        driver = new ChromeDriver();
	        psd = new PersonalSettingDetails(driver);

	        log = Logger.getLogger(StepDefinitions_PersonalSettingDetails.class);
	    }

	    @Given("User is on personal details page")
	    public void user_is_on_personal_details_page() throws InterruptedException {
	        psd.launch();
	        Thread.sleep(1000); 
	        Thread.sleep(1000);
	        log.info("User is on personal details page.");
	    }

	    @When("^User enters first name (.*)$")
	    public void user_enters_first_name(String first_name) {
	        psd.enter_firstname(first_name);
	    }

	    @When("^User enters last name (.*)$")
	    public void user_enters_last_name(String last_name) {
	        psd.enter_lastname(last_name);
	    }

	    @When("^User enters email (.*)$")
	    public void user_enters_email(String email) {
	        psd.enter_email(email);
	    }

	    @When("^User enters fax (.*)$")
	    public void user_enters_fax(String fax) {
	        psd.enter_fax(fax);
	    }

	    @When("^User enters profile name (.*)$")
	    public void user_enters_profile_name(String profile_name) {
	        psd.enter_profileName(profile_name);
	    }

	    @When("User selects the option in Is Public Wishlist {string}")
	    public void user_selects_the_option_in_is_public_wishlist(String is_public_wishlist) {
	        psd.select_IsPublicWishlist(is_public_wishlist);
	    }

	    @When("User selects the option in Is Newsletter Subscription {string}")
	    public void user_selects_the_option_in_is_newsletter_subscription(String newsletter_subscription) {
	        psd.select_NewsletterSubscription(newsletter_subscription);
	    }

	    @When("User selects the option in Is Transmail Unsubscribe {string}")
	    public void user_selects_the_option_in_is_transmail_unsubscribe(String transmail_unsubscribe) {
	        psd.select_transmailUnsubscribe(transmail_unsubscribe);
	    }

	    @When("User selects the option in Is Promomail Unsubscribe {string}")
	    public void user_selects_the_option_in_is_promomail_unsubscribe(String promomail_unsubscribe) {
	        psd.select_promomailUnsubscribe(promomail_unsubscribe);
	    }
	    
	    @When("User selects the option in country code{string}")
	    public void user_selects_the_option_in_country_code(String countryCode) throws InterruptedException  {
	    psd.select_countryCode();
	    }


	    @When("^User enters mobile number (.*)$")
	    public void user_enters_mobile_number(String mobile_number) {
	        psd.enter_mobileNumber(mobile_number);
	    }

	    @When("User clicks on the I am not a robot checkbox")
	    public void user_clicks_on_the_i_am_not_a_robot_checkbox() {
	        psd.click_checkBox();
	    }

	    @When("User clicks on the Update button")
	    public void user_clicks_on_the_update_button() {
	        psd.click_updateButton();
	    }

	    @When("^User enters the email OTP (.*)$")
	    public void user_enters_the_email_otp(String OTP) {
	        psd.enter_OTP(OTP);
	    }

	    @When("User clicks on the Verify button")
	    public void user_clicks_on_the_verify_button() {
	        psd.verify_OTP();
	    }

	    @When("User clicks on the Update button again")
	    public void user_clicks_on_the_update_button_again() {
	        psd.click_updateButton();
	    }

	    @Then("User should be able to update the personal details successfully")
	    public void user_should_be_able_to_update_the_personal_details_successfully() {
	    	  String expected = "My Account";
		        WebElement actualElement = driver.findElement(By.xpath("//*[contains(text(),\"My Account\")]"));
			    String actualText = actualElement.getText();
				    Assert.assertEquals(actualText, expected,"Personal details updated successfully");

	    }
	    @After
	    public void tearDown() {
	        if (driver != null) {
	            driver.quit(); // Close the browser
	        }
	    }
	}
