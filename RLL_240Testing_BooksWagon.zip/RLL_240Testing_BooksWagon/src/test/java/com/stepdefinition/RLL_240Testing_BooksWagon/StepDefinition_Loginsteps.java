package com.stepdefinition.RLL_240Testing_BooksWagon;
import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pages.RLL_240Testing_Bookswagon.Loginpage;
import com.pages.RLL_240Testing_Bookswagon.Signuppage;
import com.pages.RLL_240Testing_Bookswagon.homepage;


public class StepDefinition_Loginsteps {
	 WebDriver driver;
	    Loginpage loginPage;
	    homepage hp;
	    Signuppage signuppage;
	    ExtentReports extent;
	    ExtentTest test;

	    @Given("user should be in login page")
	    public void user_should_be_in_login_page() {
	        // Set up ExtentReports
	        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("report/LoginReport.html");
	        extent = new ExtentReports();
	        extent.attachReporter(htmlReporter);

	        driver = new ChromeDriver();
	        loginPage = new Loginpage(driver);
	        hp = new homepage(driver);
	        signuppage = new Signuppage(driver);
	        driver.get("https://www.bookswagon.com/login");

	        test = extent.createTest("User in Login Page");
	        test.pass("User navigated to the login page successfully.");
	    }

	    @When("user clicks on sign up link")
	    public void user_clicks_on_sign_up_link() {
	        loginPage.clickSignUpLink();
	        test = extent.createTest("Click Sign Up Link");
	        test.pass("User clicked on the sign-up link.");
	    }

	    @When("user enter otp")
	    public void user_enter_otp() {
	        String otp = ""; 
	        loginPage.enterOtp(otp);
	        test = extent.createTest("Enter OTP");
	        test.info("User entered OTP: " + otp);
	    }

	    @When("^user enter password (.*)$")
	    public void user_enter_password(String pwd) throws InterruptedException {
	        loginPage.enterPassword(pwd);
	        test = extent.createTest("Enter Password");
	        test.info("User entered password.");
	    }

	    @When("^user enter confirm password (.*)$")
	    public void user_enter_confirm_password(String confirmpwd) throws InterruptedException {
	        loginPage.enterConfirmPassword(confirmpwd);
	        test = extent.createTest("Enter Confirm Password");
	        test.info("User entered confirm password.");
	    }

	    @When("user clicks on signup button")
	    public void user_clicks_on_signup_button() throws InterruptedException {
	        loginPage.clickSignUpButton();
	        test = extent.createTest("Click Sign Up Button");
	        test.pass("User clicked the sign-up button.");
	    }

	    @Then("user should register successfully")
	    public void user_should_register_successfully() {   
	        WebElement myaccountelement = driver.findElement(By.xpath("//h1[contains(text(),\"My Account\")]"));
	        Assert.assertTrue(myaccountelement.isDisplayed());
	        test = extent.createTest("User Registration Success");
	        test.pass("User registered successfully and My Account is displayed.");
	    }

	    @After
	    public void tearDown() {
	        if (driver != null) {
	            driver.quit();
	        }
	        extent.flush(); // Flush the report
	    }
	}
