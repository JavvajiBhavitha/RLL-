package com.stepdefinition.RLL_240Testing_BooksWagon;

import static org.testng.Assert.assertTrue;
import java.time.Duration;
import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_Bookswagon.LoginPage1;
import com.pages.RLL_240Testing_Bookswagon.homepage;

import io.cucumber.java.After;
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When;
public class StepDefinition_LoginSteps1 { 

	WebDriver driver;     

	LoginPage1 lp;; 

	homepage hp; 

	Logger log1; 

	@Before 

	public void init() {   	 

		driver = new ChromeDriver();  
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		lp = new LoginPage1(driver); 

		hp = new homepage(driver); 

		log1 = Logger.getLogger(StepDefinition_LoginSteps1.class); 
	} 

	@Given("user should be in login page3") 

	public void user_should_be_in_login_page3() { 
		hp.launch(); 

		hp.clickMyAccount(); 

		log1.info("User is in login page"); 
	} 

	@When("^the user enter mobile or email (.*)$") 

	public void the_user_enter_mobile_or_email(String mobileoremail) { 

		lp.enter_mobemail(mobileoremail); 

	} 

	@When("^user enter passwords (.*)$") 

	public void user_enter_passwords(String password) { 

		lp.enter_password(password); 

	} 

	@When("user click on login button") 

	public void user_click_on_login_button() { 

		lp.Click_Login(); 

	} 

	@When("user click on forgot password") 

	public void user_click_on_forgot_password() { 

		lp.ForgotPwdLink(); 

	} 

	@When("user click on request otp") 

	public void user_click_on_request_otp() { 

		lp.ReqOtp(); 
	}  

	@When("^I enter otp (.*)$") 

	public void I_enter_otp(String otp1) throws InterruptedException { 

		lp.Enter_ReqOtp(otp1); 

	} 

	@When ("click on verify")
	public void click_on_verify() {

		lp.Verify();
	}

	@When("^user enter password1 (.*)$")  

	public void user_enter_new_password1(String forgotpassword) { 

		lp.Enter_Forgotpwd(forgotpassword); 

	} 

	@When("^enter confirm password2 (.*)$") 

	public void enter_confirm_password2(String forgotconfmpassword) { 

		lp.Enter_ConfmForgotPwd(forgotconfmpassword); 

	} 



	@When("user click login button1") 

	public void user_click_login_button1() { 

		lp.Forgot_LoginButton(); 

	} 



	@Then("user should log in successfully") 

	public void user_should_log_in_successfully() { 

		String currentUrl = driver.getCurrentUrl();
		assertTrue(currentUrl.contains("https://www.bookswagon.com/login")); 

	} 
	@After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Close the browser
        }
    }

} 

