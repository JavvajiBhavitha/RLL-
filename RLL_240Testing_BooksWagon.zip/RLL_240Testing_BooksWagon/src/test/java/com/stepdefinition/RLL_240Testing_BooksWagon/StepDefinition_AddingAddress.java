package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import com.pages.RLL_240Testing_Bookswagon.AddingAddress;
import com.pages.RLL_240Testing_Bookswagon.Loginpage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_AddingAddress {



	WebDriver driver;
	AddingAddress ap;

	Loginpage lp;

	@Before
	public void init() {
		driver=new ChromeDriver();
		ap=new AddingAddress(driver);
		lp= new Loginpage(driver);
	}


	@Given("user should be in addresses page")
	public void user_should_be_in_addresses_page() throws InterruptedException {
		// Initialize the WebDriver and navigate to the addresses page
		ap.Launch_App();
		
		driver.navigate().to("https://www.bookswagon.com/addaddress.aspx");
		Thread.sleep(4000);
	}

	@When("^user enters FullName(.*)$")
	public void user_enters_FullName(String Full_Name) {
		ap.Fullname(Full_Name);

	}

	@When("^user enters CompanyName(.*)$")
	public void user_enters_CompanyName(String Company_Name) {
		ap.CompanyName(Company_Name);
	}


	@When("^user enters StreertAddress(.*)$")
	public void user_enters_StreertAddress(String Streert_Address) {
		ap.StreetAddress(Streert_Address);
	}

	@When("^user enters Landmark(.*)$")
	public void user_enters_Landmark(String Land_mark) {
		ap.Landmark(Land_mark);
	}

	@When("^user selects Country(.*)$")
	public void user_selects_Country(String Country) {
		ap.Country(Country);
	}

	@When("^user selects State(.*)$")
	public void user_selects_State(String State) throws InterruptedException {
		ap.State(State);
	}

	@When("^user selects City(.*)$")
	public void user_selects_City(String City) throws InterruptedException {
		ap.selectcity(City);
	}

	@When("^user enters ZipCode(.*)$")
	public void user_enters_ZipCode(String Zip_Code) {
		ap.Zipcode(Zip_Code);
	}

	@When("^user enters Mobileno(.*)$")
	public void user_enters_Mobileno(String Mobile_no) {
		ap.Mobile(Mobile_no);;
	}

	@When("^user enters Phoneno(.*)$")
	public void user_enters_Phoneno(String Phone_no) {
		ap.phone(Phone_no);
	}

	@When("user clicks on Checkbox")
	public void user_clicks_on_Checkbox() {
		ap.checkbox();
	}

	@When("user clicks on Update Button")
	public void user_clicks_on_Update_Button() {
		ap.Update();
	}

	@Then("user Should add address successfully")
	public void user_Should_add_address_successfully() {

		WebElement head = driver.findElement(By.xpath("(//*[contains(text(),'Busireddashwini')])")); // Replace with actual ID or XPath
		Assert.assertTrue(head.isDisplayed(),"Address was not added successfully");
		System.out.println("Address added successfully");
	}
	@After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Close the browser
        }
	}
}



