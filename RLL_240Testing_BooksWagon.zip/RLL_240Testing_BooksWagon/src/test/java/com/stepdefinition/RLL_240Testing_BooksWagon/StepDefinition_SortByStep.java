
package com.stepdefinition.RLL_240Testing_BooksWagon;

import java.time.Duration;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pages.RLL_240Testing_Bookswagon.SortByPage;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition_SortByStep {
    WebDriver driver;
    SortByPage sortByPage;
    WebDriverWait wait;
    Logger log2;
    ExtentReports extent;
    ExtentTest test;

    @Before
    public void setUp() {
        // Set up ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("reports/reportSortBy.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);

        driver = new ChromeDriver();
        sortByPage = new SortByPage(driver);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        log2 = Logger.getLogger(StepDefinition_SortByStep.class);
    }

    @Given("the user has launched the application")
    public void the_user_has_launched_the_application() {
        test = extent.createTest("Launch Application");
        sortByPage.launch();
        Assert.assertEquals("URL should match the expected BooksWagon page", "https://www.bookswagon.com/promo-best-seller/award-winning/2109CDC4B4DC", driver.getCurrentUrl());
        test.pass("Application launched successfully and URL matched.");
    }

    @When("user clicks on sortBy section")
    public void user_clicks_on_sortBy_section() {
        test = extent.createTest("Navigate to Sort By Section");
        sortByPage.navigateToSortBy();
        log2.info("User navigated to Sort By section");
        Assert.assertEquals("AwardWinners", driver.getCurrentUrl());
        test.pass("Navigated to Sort By section and URL matched.");
    }

    @Then("the user should be able to see sorting options")
    public void the_user_should_be_able_to_see_sorting_options() {
        log2.info("User displayed Sort By options");
        test.pass("Sort By options displayed.");
    }

    @Given("the user is in the Award Winners section")
    public void the_user_is_in_the_award_winners_section() {
        test = extent.createTest("Check in Award Winners Section");
        sortByPage.launch(); // Ensure we are in the correct section
        Assert.assertEquals("URL should match the expected BooksWagon page", "https://www.bookswagon.com/promo-best-seller/award-winning/2109CDC4B4DC", driver.getCurrentUrl());
        test.pass("User is in the Award Winners section and URL matched.");
    }

    @When("the user selects price")
    public void the_user_selects_price() {
        test = extent.createTest("Select Price Sort Option");
        sortByPage.sortByPrice();
        System.out.println("User clicks on price");
        test.info("User clicked on price sort option.");
    }

    @And("user clicks on discount")
    public void user_cliks_on_discount() {
        test = extent.createTest("Select Discount Sort Option");
        sortByPage.sortByDiscount();
        test.info("User clicked on discount sort option.");
    }

    @Then("the user should see the books sorted")
    public void the_user_should_see_the_books_sorted() {
        System.out.println("Books are sorted");
        test.pass("Books sorted successfully.");
    }

    @Given("the user Award Winners section")
    public void the_user_award_winners_section() {
        test = extent.createTest("Check Award Winners Section");
        sortByPage.launch(); 
    }

    @When("I do not select any sorting option")
    public void i_do_not_select_any_sorting_option() {
        test = extent.createTest("Verify Default Sorting");
        sortByPage.verifyDefaultSorting();
        System.out.println("Default sorting applied.");
        test.info("Default sorting verified.");
    }

    @Then("the user should see the books in the default sorting order")
    public void the_user_should_see_the_books_in_default_sorting_order() {
        Assert.assertEquals("Books should be displayed in the default sorting order", driver.getTitle());
        test.pass("Books displayed in default sorting order.");
    }

    @After
    public void tearDown() {
        driver.quit();
        extent.flush();
        log2.info("Driver closed and extent report flushed.");
    }
}

