package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.apache.log4j.Logger;

import org.junit.Assert;
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver;

import com.pages.RLL_240Testing_Bookswagon.AddingItemtoShoppingCart;

import io.cucumber.java.After;

//import com.pages.RLL_240Testing_BooksWagon_ShoppingCart.AddingItemtoShoppingCart; 

import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 

public class StepDefinition_AddingItemtoShoppingCartSteps { 
	WebDriver driver; 
	AddingItemtoShoppingCart ac; 
	Logger log23;
	private boolean isItemAdded;
	private int cartItemCount;

	@Before 
	public void init() { 
		driver = new ChromeDriver(); 
		ac= new AddingItemtoShoppingCart(driver); 
		log23=Logger.getLogger(StepDefinition_AddingItemtoShoppingCartSteps.class);
	} 

	@Given ("the user is on the product page") 
	public void the_user_is_on_the_product_page() {
		log23.info("user is in product page");

	} 
	@When ("the user clicks on the item") 
	public void the_user_clicks_on_the_item() throws InterruptedException { 
		ac.ClickBookName(); 
		log23.info("user clicked on item");
	} 
	@When ("the user clicks on the Add to Cart button") 
	public void the_user_clicks_on_the_Add_to_Cart_button() throws InterruptedException { 
		ac.addItemToCart();	 
	} 
	@When ("the item should be added to the shopping cart") 
	public void the_item_should_be_added_to_the_shopping_cart() {
		Assert.assertTrue("Item was not added to the cart", isItemAdded);
		log23.info("the item added to the cart");
	} 
	@Then ("the shopping cart should be updated with the new item") 
	public void the_shopping_cart_should_be_updated_with_the_new_item() {
		Assert.assertTrue("Shopping cart was not updated", cartItemCount > 0);

	}	 
	@After
	public void tearDown() {
		if (driver != null) {
			driver.quit(); // Close the browser
		}
	}
} 
