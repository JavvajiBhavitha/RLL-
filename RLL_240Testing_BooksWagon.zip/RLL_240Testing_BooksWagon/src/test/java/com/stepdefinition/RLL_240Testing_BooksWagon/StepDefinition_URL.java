//package com.stepdefinition.RLL_240Testing_BooksWagon;
//import org.apache.log4j.Logger;
//import org.openqa.selenium.By; 
//
//import org.openqa.selenium.WebDriver; 
//import org.openqa.selenium.WebElement; 
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.Assert;
//
//import com.pages.RLL_240Testing_Bookswagon.Page_File_Search_RefineSearch;
//import com.pages.RLL_240Testing_Bookswagon.Page_File_URL;
//
//import io.cucumber.java.After;
//import io.cucumber.java.Before; 
//import io.cucumber.java.en.Given; 
//import io.cucumber.java.en.When; 
//import io.cucumber.java.en.Then;
//public class StepDefinition_URL {
//
//WebDriver driver; 
//	Page_File_URL pg; 
//	//Logger log1;
//	Page_File_Search_RefineSearch sr1;	 
//	@Before 
//	public void init() 
//	{ 
//		driver=new ChromeDriver();
// 
//		pg= new Page_File_URL(driver); 
//		sr1 = new Page_File_Search_RefineSearch(driver); 
//	  // log1= Logger.getLogger(Step_Definition_URL.class);
//	}
// 
//	@Given("the user navigates to the application URL") 
//	public void the_user_navigates_to_the_application_URL() throws InterruptedException { 
//		//driver.get("https://www.bookswagon.com/"); 
//		pg.Launch(); 
//		Thread.sleep(3000);
//		//log1.info("the user navigates the application");
//	}
// 
//	@When("^the user enters (.*)$") 
//	public void the_user_enters(String Input1) throws InterruptedException { 
//		WebElement Search12 =driver.findElement(By.id("inputbar"));
//		Search12.sendKeys(Input1);
//		Search12.click();
//		//pg.enterSearchItem("The Secret"); 
//		Thread.sleep(3000); 
//	}
// 
//	@When("clicks the search button") 
//	public void clicks_the_search_button() throws InterruptedException { 
//		//driver.findElement(By.id("btnTopSearch")).click(); 
//		pg.clickSearchButton();
//		Thread.sleep(3000);		
//	}
// 
//	@Then("the user can able to check the search item in the search result") 
//	public void the_user_can_able_to_check_the_search_item_in_the_search_result(String expectedResult) throws InterruptedException { 
//		if (expectedResult.equals("Your search  did not match any books.")) { 
//			WebElement noResultsMessage = driver.findElement(By.id("noResultsMessageId")); 
//			String actualMessage = noResultsMessage.getText(); 
//			Thread.sleep(3000);
//			  Assert.assertTrue(actualMessage.contains(expectedResult)); 
//		} else { 
//			WebElement searchResults = driver.findElement(By.id("searchResultsId")); 
//			String actualResult = searchResults.getText(); 
//			  Assert.assertTrue(actualResult.contains(expectedResult)); 
//			Thread.sleep(3000);
//		} 
//		System.out.print("Output");
//		driver.quit(); 
//	} 
//	@After
//	public void teardown() {
//		if(driver!=null) {
//			driver.quit();
//		}
//	}
//}
