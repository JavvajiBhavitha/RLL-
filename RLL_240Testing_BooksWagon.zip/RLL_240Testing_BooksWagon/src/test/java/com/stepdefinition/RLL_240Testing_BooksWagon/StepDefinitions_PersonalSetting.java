package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.apache.log4j.Logger;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import com.pages.RLL_240Testing_Bookswagon.PersonalSetting;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinitions_PersonalSetting {

	  WebDriver driver;
      PersonalSetting ps; 
      Logger log13;
      
  	@Before
  	public void init() {
  		driver = new ChromeDriver();
  		ps = new PersonalSetting(driver);
  		log13 = Logger.getLogger(StepDefinitions_PersonalSetting.class);
  	}
	@Given("User is on login page")
   public void user_is_on_login_page() throws InterruptedException {
		ps.launch();
		Thread.sleep(1000);
		Thread.sleep(1000);

        driver.navigate().to("https://www.bookswagon.com/myaccount.aspx");
        Thread.sleep(5000);
  

   }
   @When("User clicks on Personal Settings")
   public void user_clicks_on_personal_settings() {
    ps.click_personalSettingsButton();
   
   }

   @Then("User should be able to click on Personal Settings option")
   public void user_should_be_able_to_click_on_personal_settings_option() {
	   String expected = "Personal Settings";
  	    WebElement actualElement = driver.findElement(By.xpath("//*[contains(text(),\"Personal Settings\")]"));
  	    String actualText = actualElement.getText();
  	    Assert.assertEquals(actualText, expected,"personal settings option is clicked");
   }
   @After
   public void tearDown() {
       if (driver != null) {
           driver.quit(); // Close the browser
       }
   }
}
 	  
	

	 