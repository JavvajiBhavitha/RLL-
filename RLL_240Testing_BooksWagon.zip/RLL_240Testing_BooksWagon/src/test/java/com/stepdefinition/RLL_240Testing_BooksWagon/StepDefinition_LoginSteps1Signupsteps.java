package com.stepdefinition.RLL_240Testing_BooksWagon;

import io.cucumber.java.After;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import static org.testng.Assert.assertTrue;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.pages.RLL_240Testing_Bookswagon.Loginpage;
import com.pages.RLL_240Testing_Bookswagon.Signuppage;
import com.pages.RLL_240Testing_Bookswagon.homepage;




public class StepDefinition_LoginSteps1Signupsteps {
	 WebDriver driver;
	    Loginpage loginPage;
	    Signuppage signuppage;
	    homepage hp; 
	    ExtentReports extent;
	    ExtentTest test;

	    @Given("the user is on the sign-up page")
	    public void userIsOnSignUpPage() {
	        // Set up ExtentReports
	        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("report/SignupReport.html");
	        extent = new ExtentReports();
	        extent.attachReporter(htmlReporter);

	        // Set up the WebDriver
	        System.setProperty("webdriver.chrome.driver", "path/to/chromedriver");
	        driver = new ChromeDriver();
	        driver.get("https://www.bookswagon.com/login#"); // Replace with your actual signup page URL

	        // Initialize the page objects
	        signuppage = new Signuppage(driver);
	        hp = new homepage(driver);
	        loginPage = new Loginpage(driver);
	        
	        test = extent.createTest("User on Sign-Up Page");
	        test.pass("User navigated to the sign-up page successfully.");
	    }

	    @When("^the user enters their name (.*)$")
	    public void userEntersName(String name) throws InterruptedException {
	        signuppage.enterName(name);
	        test = extent.createTest("Enter Name");
	        test.info("User entered name: " + name);
	    }

	    @When("^the user enters their mobile number (.*)$")
	    public void userEntersMobileNumber(String phno) throws InterruptedException {
	        signuppage.enterMobileNumber(phno);
	        test = extent.createTest("Enter Mobile Number");
	        test.info("User entered mobile number: " + phno);
	    }

	    @When("the user clicks the continue button")
	    public void userClicksContinueButton() throws InterruptedException {
	        signuppage.clickContinueButton();
	        test = extent.createTest("Click Continue Button");
	        test.pass("User clicked the continue button.");
	    }

	    @Then("the user should be taken to the next step")
	    public void userShouldBeTakenToNextStep() {
	        String currentUrl = driver.getCurrentUrl();
	        assertTrue(currentUrl.contains("https://www.bookswagon.com/login")); 
	        test = extent.createTest("Verify Navigation to Next Step");
	        test.pass("User was taken to the next step successfully.");
	    }

	    @Then("the user closes the browser")
	    public void userClosesBrowser() {
	        driver.quit();
	        test = extent.createTest("Close Browser");
	        test.pass("User closed the browser.");
	        extent.flush(); // Flush the report
	    }
	}
