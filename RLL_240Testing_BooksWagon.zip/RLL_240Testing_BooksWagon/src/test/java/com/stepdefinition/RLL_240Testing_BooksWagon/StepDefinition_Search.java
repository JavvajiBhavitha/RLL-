package com.stepdefinition.RLL_240Testing_BooksWagon;
import org.openqa.selenium.By; 


import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When; 
import io.cucumber.java.en.Then; 
import org.testng.Assert;
import org.testng.log4testng.Logger;

import com.pages.RLL_240Testing_Bookswagon.Page_File_Search_RefineSearch;

public class StepDefinition_Search { 

	WebDriver driver;  
	 
	Page_File_Search_RefineSearch sr1; 
	//Logger log2;
 
	@Before
 
	public void init() 
	{ 
		driver=new ChromeDriver();	
 
		sr1 = new Page_File_Search_RefineSearch(driver);
	  //  Logger log2 = Logger.getLogger(Step_Definition_Search.class);
 
	}
 
 
	@Given("the user is on Search_Result page")
 
	public void the_user_is_on_Search_Result_Page() { 
		//driver.get("https://www.bookswagon.com/search-books/the-secret"); 
		//log2.info("user is on Search_Result page");
		sr1.Navigate_To_Result_Page();
 
 
	}
 
 
	@When("^user enter search item(.*) $")
 
	public void user_enter_search_item(String input) throws InterruptedException {
 
		driver.findElement(By.id("inputbar")).sendKeys(input);
 
		sr1.enterSearchItem("The secret"); 
		Thread.sleep(3000);
 
	}
 
	@When("click on the search button")
 
	public void click_on_the_search_button() throws InterruptedException {
 
		//driver.findElement(By.id("btnTopSearch")).click();
 
		sr1.clickSearchButton(); 
		Thread.sleep(3000);
 
	} 
	@Then("the user should see expected result")
 
	public void the_user_should_see_expected_result(String expectedResult) throws InterruptedException {
 
		if (expectedResult.equals("Your search - '16354e4@$43' - did not match any books.")) {
 
			//Locate the element that contains the no results message
 
			WebElement noResultsMessageElement = driver.findElement(By.id("noResultsMessageId")); // Use the appropriate locator
 
			String actualMessage = noResultsMessageElement.getText();
 
			Assert.assertTrue(actualMessage.contains(expectedResult)); 
			Thread.sleep(3000);
			noResultsMessageElement.clear();

 
		} else {
 
			// Locate the element that contains the search results
 
			WebElement searchResultsElement = driver.findElement(By.id("searchResultsId")); // Use the appropriate locator
 
			String actualResult = searchResultsElement.getText();
 
			Assert.assertTrue(actualResult.contains(expectedResult)); 
		} 
	} 
	@After
	public void teardown() {
		if(driver!=null) {
			driver.quit();
		}
	}
 
}
