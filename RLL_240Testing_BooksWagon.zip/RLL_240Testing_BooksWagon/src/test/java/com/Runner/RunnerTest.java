package com.Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests; 


import io.cucumber.testng.CucumberOptions; 

@CucumberOptions(features = "src/test/resource/com/features_RLL240Testing_BooksWagon", 

glue = "com.stepdefinition.RLL_240Testing_BooksWagon", 

plugin = {"pretty", "html:target/cucumber-reports.html"}, 
tags=" @homepage or @login1 or @signup1",
monochrome = true 

		) 
public class RunnerTest extends AbstractTestNGCucumberTests{ 



} 
